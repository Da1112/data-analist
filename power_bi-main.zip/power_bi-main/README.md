# power_bi
repaso de power bi 
